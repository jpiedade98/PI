# Projeto Site Escolar Univesp 2024

### Descrição
O __Projeto Site Escolar Univesp 2024__ tem como objetivo facilitar a comunicação entre pais, alunos e direção escola

__Link da aplicação__ //C:/Users/TSP/Desktop/Projeto%20PI/projeto-escola-web-main/projeto-escola-web-main/index.html
